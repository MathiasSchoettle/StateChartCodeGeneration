import socket
import sys

# erwartet Namen des SysML-Blocks (nicht der Instanz wegen multipler Instanzen und Problemen mit StateMachines der Instanzen in Modelio
def getAbstrStateMachine(ComponentName) :
	m = session.findByClass(AbstractDiagram)
	for d in m :
		if isinstance(d,StateMachineDiagram) :
			owner = d.getOrigin().getOwner()
			if isinstance(owner,Class) :
				if owner.getName() == ComponentName :
					return d



# erster Aufruf der Funktion auf vollem Namen (z.B. "Comp/State1/Region1/State11" mit
#        node = getStateNode(StateName,None,"component")
#   liefert None, wenn State nicht gefunden wurde
def getStateNode(StateName, GraphNode, kind) :
	if kind == "component" :
		# Komponente suchen und dann die Knoten durchgehen
		# Namen kürzen und dann für alle Nodes, die States sind, rekrusiv mit kind=state aufrufen
		splitName = StateName.split("/",1)
		compName = splitName[0]
		dh = getAbstrStateMachine(compName)
		if dh is None:
			return None
		dn = Modelio.getInstance().getDiagramService().getDiagramHandle(dh).getDiagramNode().getNodes()
		for node in dn :
			if node.getElement().getMClass().getName()=="State" :
				nh = getStateNode(splitName[1], node, "state")
				if not nh is None : 
					return nh
		return None
	if kind == "state" :
		# State suchen, wenn StateName dann leer ist, dann Node zurückgeben, ansonsten rekursiven Aufruf mit kind="region"
		splitName = StateName.split("/",1)
		stName = splitName[0]
		if stName != GraphNode.getName() :
			return None
		if len(splitName)>1 :
			subNodes = GraphNode.getNodes()
			for sn in subNodes :
				if not sn.getElement().getMClass().getName()=="Region" :
					continue
				foundNode = getStateNode(splitName[1], sn, "region")
				if not foundNode is None :
					return foundNode
			return None
		else :
			return GraphNode
	else :
		# Region suchen, wenn StateName dann leer ist, dann Node zurückgeben, ansonsten rekursiven Aufruf mit kind="state"
		splitName = StateName.split("/",1)
		if len(splitName)==1 :
			# in diesem Fall ein Fehler, da für einen State nicht eine Region das letzte Element des Namens sein darf
			print "Error: Eine Region darf nicht das Ende eines State-Namens sein"
			return None
		regName = splitName[0]
		if regName != GraphNode.getName() :
			return None
		if len(splitName)>1 :
			subNodes = GraphNode.getNodes()
			for rn in subNodes :
				if not rn.getElement().getMClass().getName()=="State" :
					continue
				foundNode = getStateNode(splitName[1], rn, "state")
				if not foundNode is None :
					return foundNode
			return None
		else :
			return GraphNode
	return None



def deactivateState(StateName) :
	node = getStateNode(StateName,None,"component")
	if node is None :
		print "Error: Node nicht gefunden!" + StateName
		return False
	node.setLineWidth(1)
	node.setLineColor("0,0,0")
	return True



def activateState(StateName) :
	node = getStateNode(StateName,None,"component")
	if node is None :
		print "Error: Node nicht gefunden!"+ StateName
		return False
	node.setLineWidth(5)
	node.setLineColor("255,0,0")
	return True





# alten Socket löschen
if 'sock' in locals() :
	sock.close()
	del sock
print 'Warte auf Simulationsclient ...'
# Socket aufbauen und auf Verbindung zu Client warten
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server_address = ('localhost', 54345)
sock.bind(server_address)
sock.listen(1)
connection, client_address = sock.accept()
print 'Simulation verbunden'
# Initialberechnung auf Client initiieren
#initCmd = "init"
#connection.sendall(initCmd)


