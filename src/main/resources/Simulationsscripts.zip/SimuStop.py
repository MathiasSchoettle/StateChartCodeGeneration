quitcmd = "quit"
connection.sendall(quitcmd)
connection.close()
sock.close()
del sock
del connection
print "Simualation beeendet"
