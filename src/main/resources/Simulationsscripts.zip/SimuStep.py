cmd = "do_step"
connection.sendall(cmd)
response = ""
while response.find("$DONE")==-1 :
	data = connection.recv(4096)
	response += data
simuCmd = response.split("$",1)
timeStringParts = simuCmd[0].split("=")
# Zeitschritt extrahieren
print "----------------------"
print "Zeitschritt %s: " % timeStringParts[1]
stateChanges = simuCmd[1].split("$")
for sc in stateChanges :
	if sc=="DONE" :
		continue
	if sc.find("+")!=-1 :
		sName = sc.split("+")
		activateState(sName[1])
	else :
		sName = sc.split("-")
		deactivateState(sName[1])
	





